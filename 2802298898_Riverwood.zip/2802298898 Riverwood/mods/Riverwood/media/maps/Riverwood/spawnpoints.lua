function SpawnPoints()
return {

  mechanic = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  Metalworker = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  unemployed = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  burgerflipper = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  burglar = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  carpenter = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  chef = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  constructionworker = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  doctor = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  electrician = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  engineer = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  farmer = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  fireofficer = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  fisherman = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  Fitnessinstructor = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  lumberjack = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  nurse = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  parkranger = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  policeofficer = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  repairman = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  securityguard = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  },

  veteran = {
    { worldX = 26, worldY = 24, posX = 192, posY = 28, posZ = 0 },
  }
}
end
